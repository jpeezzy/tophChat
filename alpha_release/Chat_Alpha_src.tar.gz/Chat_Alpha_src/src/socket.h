#ifndef SOCKET_H
#define SOCKET_H

//Function that allows the client to be connected to the server
int connectToServer(int portNum, char* hostName);
#endif 
