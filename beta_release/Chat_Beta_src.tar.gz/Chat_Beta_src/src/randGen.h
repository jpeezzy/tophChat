#ifndef RANDGEN_H
#define RANDGEN_H

unsigned long int randNum();


#endif
