#ifndef _TEST_STRING_H
#define _TEST_STRING_H
#include "constants.h"
char testString1[PACKAGE_SIZE]="TESsdlfkj;sdljglkjweori;wuqoi;rfjdslkljfklasjfmlk23878912klfjelk";

#endif