#ifndef _ENCRYPT_H
#define _ENCRYPT_H

void encrypt(char input[500], unsigned long int key);
void decrypt(char input[500], unsigned long int key);

#endif